#python convert_to_rouge.py --ref_data_dir ../City_4_logs/explanation --gen_data_dir ../City_4_logs/explanation --test_number 746
#ROUGE-1.5.5/ROUGE-1.5.5.pl -e ROUGE-1.5.5/data/ -n 4 -m -2 4 -u -c 95 -r 1000 -f B -p 0.5 -t 0 config.xml > City_4_rouge_result.txt None

#python convert_to_rouge.py --ref_data_dir ../City_2_logs/explanation --gen_data_dir ../City_2_logs/explanation --test_number 2557
#ROUGE-1.5.5/ROUGE-1.5.5.pl -e ROUGE-1.5.5/data/ -n 4 -m -2 4 -u -c 95 -r 1000 -f B -p 0.5 -t 0 config.xml > City_2_rouge_result.txt None

#python convert_to_rouge.py --ref_data_dir ../yelp_log/NV_log/explanation --gen_data_dir ../yelp_log/NV_log/explanation --test_number 1756
#ROUGE-1.5.5/ROUGE-1.5.5.pl -e ROUGE-1.5.5/data/ -n 4 -m -2 4 -u -c 95 -r 1000 -f B -p 0.5 -t 0 config.xml > NV_2019data_v5_rouge_result.txt None

# AZ 2366
#python convert_to_rouge.py --ref_data_dir ../AZ_log/30:01:12:18:06/explanation --gen_data_dir ../AZ_log/30:01:12:18:06 --test_number 2366
#ROUGE-1.5.5/ROUGE-1.5.5.pl -e ROUGE-1.5.5/data/ -n 4 -m -2 4 -u -c 95 -r 1000 -f B -p 0.5 -t 0 config.xml > dianping_AZ_30:01:12:18:06_rouge_result.txt None


#City4 746
python convert_to_rouge.py --ref_data_dir ../ERCP_C_City4_log/31:01:00:42:49/explanation --gen_data_dir ../ERCP_C_City4_log/31:01:00:42:49/explanation --test_number 746
ROUGE-1.5.5/ROUGE-1.5.5.pl -e ROUGE-1.5.5/data/ -n 4 -m -2 4 -u -c 95 -r 1000 -f B -p 0.5 -t 0 config.xml > City4_31:01:00:42:49_rouge_result.txt None

#ON 1726
#python convert_to_rouge.py --ref_data_dir ../ERCP_C_ON_log/30:01:12:17:44/explanation --gen_data_dir ../ERCP_C_ON_log/30:01:12:17:44/explanation --test_number 1726
#ROUGE-1.5.5/ROUGE-1.5.5.pl -e ROUGE-1.5.5/data/ -n 4 -m -2 4 -u -c 95 -r 1000 -f B -p 0.5 -t 0 config.xml > ON_30:01:12:17:44_rouge_result.txt None


#City2 1656
#python convert_to_rouge.py --ref_data_dir ../ERCP_C_City2_log/29:01:19:22:13/explanation --gen_data_dir ../ERCP_C_City2_log/29:01:19:22:13/explanation --test_number 1656
#ROUGE-1.5.5/ROUGE-1.5.5.pl -e ROUGE-1.5.5/data/ -n 4 -m -2 4 -u -c 95 -r 1000 -f B -p 0.5 -t 0 config.xml > City2_29:01:19:22:13_rouge_result.txt None